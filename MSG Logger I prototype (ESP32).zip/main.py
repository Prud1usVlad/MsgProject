import network
import time
from machine import Pin, ADC
import dht
import ujson
from umqtt.simple import MQTTClient
import math

DEVICE_VERSION = "0.1.0"
DEVICE_ID = 1
MQTT_CLIENT_ID = "clientId-StyKLrNS0m"
MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = "8883"
MQTT_USER = "user-" + str(DEVICE_ID)
MQTT_PASSWORD = "****"
MQTT_TOPIC = "msg-measuring"

sensor = dht.DHT22(Pin(15))
timer = ADC(Pin(34))
timer.atten(ADC.ATTN_11DB)

switch = ADC(Pin(35))

measuring_delay = 1;

def map(val, loval, hival, tolow, tohigh):
  return (val - loval)/(hival-loval)*(tohigh-tolow) + tolow

def get_hours_delay(adc_value) :
  return math.ceil((adc_value) / (4095 / 23)) + 1

def connect_to_wifi() : 
  print("Connecting to WiFi", end="")
  sta_if = network.WLAN(network.STA_IF)
  sta_if.active(True)
  sta_if.connect('Wokwi-GUEST', '')
  while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.1)
  print(" Connected!")

def connect_to_brocker() :
  print("Connecting to MQTT server... ", end="")
  client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER)
  client.connect()
  print("Connected!")

  return client

def send_data(prev_data, client) : 
  message = ujson.dumps({
    "deviceVersion" : DEVICE_VERSION,
    "deviceId": DEVICE_ID,
    "data": [
      {
        "dataPieceId": 1,
        "name": "Acidity",
        "value": map(sensor.temperature(), -40, 80, 0, 14),
      },
      {
        "dataPieceId": 2,
        "name": "Electrical Capacity",
        "value": map(sensor.temperature(), -40, 80, 6, 6.5),
      },
      {
        "dataPieceId": 3,
        "name": "Moisure Content",
        "value": sensor.humidity(),
      }
    ]
  })

  if message != prev_data:
    print("Updated!")
  else:
    print("No change")

  print("Reporting to MQTT topic {}: {}".format(MQTT_TOPIC, message))
  client.publish(MQTT_TOPIC, message)

  return message

def wait(delay) :
  print("Waiting for {} seconds".format(delay))

  exit_function = False

  for i in range(delay) : 
    if (switch.read() == 0) :
      print("-----------------------")
      print("Data logging turned off")

      while True :
        if (switch.read() == 0) : 
          time.sleep(1)
        else :
          print("Data logging turned on")
          print("-----------------------")
          exit_function = True
          break
    elif (exit_function) :
      break
    else :
      time.sleep(1)

def main() :
  connect_to_wifi()
  client = connect_to_brocker()

  prev_data = ""
  while True:
    
    # Delay beetwen measurings in seconds  
    measuring_delay = get_hours_delay(timer.read())

    print("Measuring weather conditions... ", end="")
    sensor.measure()

    prev_data = send_data(prev_data, client)

    wait(measuring_delay)


main()

